<div align="center"><h1>❖❖❖❖❖   𝐒𝐄𝐖 𝐐𝐔𝐄𝐄𝐍   ❖❖❖❖❖</h1><a href="https://github.com/ravindu01manoj/Sew-Queen"><img src="https://i.ibb.co/9Ngt7rH/c32a378c86f6.jpg" width="250" height="250"></a><h3>✬✬ Sew Queen Is World Best Whatsapp Bot Ever ✬✬</h3></div>


***

<p align="center"><a href="httsp://github.com/ravindu01manoj/Sew-Queen"><img src="https://img.shields.io/docker/pulls/ravindu01manoj/sewqueen?style=for-the-badge&logo=docker&label=Docker+Pulls&color=blueviolet"></a><a href="https://github.com/ravindu01manoj/Sew-Queen"><img src="https://img.shields.io/docker/image-size/ravindu01manoj/sewqueen?style=for-the-badge&logo=docker&label=Image Size&color=blueviolet"></a></p><p align="center"><a href="https://github.com/ravindu01manoj/Sew-Queen"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fravindu01manoj%2FSew-Queen&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false" alt="Views"/></a></a><a href="https://github.com/ravindu01manoj/Sew-Queen/fork"><img src="https://img.shields.io/github/forks/ravindu01manoj/Sew-Queen?label=Fork&style=social"></a><a href="https://github.com/ravindu01manoj/Sew-Queen/stargazers"><img src="https://img.shields.io/github/stars/ravindu01manoj/Sew-Queen?style=social"></a></p><p align="center"><a href="httsp://github.com/ravindu01manoj/Sew-Queen"><img src="https://img.shields.io/github/repo-size/ravindu01manoj/Sew-Queen?color=00ff00&label=Repo%20Size&style=flat-square"></a><a href="httsp://github.com/ravindu01manoj/Sew-Queen"><img src="https://img.shields.io/github/license/ravindu01manoj/Sew-Queen?color=00ff00&label=License&style=flat-square"></a><a href="httsp://github.com/ravindu01manoj/Sew-Queen"><img src="https://img.shields.io/github/languages/top/ravindu01manoj/Sew-Queen?color=00ff00&label=Javascript&style=flat-square"></a><a href="httsp://github.com/ravindu01manoj/Sew-Queen"><img src="https://img.shields.io/badge/Programmer-Ravindu%20Manoj-blueviolet"></a></p><p align="center"><a href="https://t.me/RavinduManoj"><img src="https://img.shields.io/badge/Contact%20Me%20With%20Telegrame-Ravindu%20Manoj-success"></a></p>

***
> scan  QR Code ✏
<div align="left"><a href="https://replit.com/@RavinduManoj/Queen-Sew-QR-Code"><img src="https://i.ibb.co/5WRBdGh/ab1985860df7.jpg" width="150" ></a></div>

---
> Deploy Your Bot On Heroku ✏
<div align="left"><a href="https://dashboard.heroku.com/new?button-url=https%3A%2F%2Fgithub.com%2FSew01RaviduManoj01KingAndQueen%2FQueenSew1&template=https%3A%2F%2Fgithub.com%2FSewRavindu01ManojKing%2FQueenSew"><img src="https://i.ibb.co/WPRfjrZ/c6eb7d6b6606.png" width="150" ></a></div>

***
<div aline='left'><h2> SEW QUEEN TEAM </h2></div>

***


<table><tr><th>Ms:Sew</th><th>Ravindu Manoj </th></tr><tr><td><a href="https://github.com/ravindu01manoj"><img src="https://i.ibb.co/3z76kRG/03d3250f68e2.jpg" width="180" alt="Sew Queen"></a></td><td><a href="https://github.com/ravindu01manoj"><img src="https://i.ibb.co/GMDtzJK/9c7cd57913d3.jpg" width="180" alt="Ravindu Manoj"></a></td></tr><tr><td>Owner</td><td>Developer & Owner </td></tr></table><table><tr><th>Muthu</th><th>Dilusha</th><th>Umeda</th></tr><tr><td><a href="https://github.com/ravindu01manoj"><img src="https://i.ibb.co/Ph9cxMm/6c995889c9b9.jpg" width="180" alt="Muthu"></a></td><td><a href="http://github.com/dilushamandila"><img src="https://i.ibb.co/qRZ0cqd/7ac4bab5ced2.jpg" width="180" alt="Dilusha"></a></td><td><a href="http://github.com/umedaewandee"><img src="https://i.ibb.co/fFDw0K5/8190782ff481.jpg" width="180" alt="Umeda"></a></td></tr><tr><td>Voice & Idea </td><td> Graphics & Group Management</td><td>Group Management & Idea</td></tr></table>


***
<div align="center"><h1>✬✬ Sew Queen Is World Best Whatsapp Bot Ever ✬✬</h1><a href="https://github.com/ravindu01manoj/Sew-Queen"><img src="https://github.com/ravindu01manoj/ravindu01manoj/blob/1d9ff8a76d20d4d151780c68c59beeb68b318e88/media/ezgif.com-video-to-gif%20(1).gif" width="450"></a></div>

***
> Another Way To Get Qr ✏

# You Can Get Qr Easily Using Another Sew Queen Bot
# Get Qr As Image To Use .getqr

> termux code for qr✏


```
$ pkg upgrade && pkg update
$ pkg install nodejs && pkg install git
```

```
$ git clone https://github.com/Sew01RaviduManoj01KingAndQueen/sew.git
$ cd qr
$ npm i
$ node sew.js

```
```
$ cd qr
$ node sew.js
```
